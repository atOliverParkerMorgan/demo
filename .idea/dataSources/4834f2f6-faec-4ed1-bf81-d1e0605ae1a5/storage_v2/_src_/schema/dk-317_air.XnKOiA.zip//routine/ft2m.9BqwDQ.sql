create
    definer = `dk-317`@localhost function ft2m(ft float) returns float
    RETURN ft * 0.3048;

