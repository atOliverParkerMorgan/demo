create
    definer = `dk-317`@localhost function geo_distance(s_latitude float, s_longitude float, d_latitude float,
                                                       d_longitude float) returns float
    RETURN (ACOS(SIN(s_latitude * PI() / 180) * SIN(d_latitude * PI() / 180) + COS(s_latitude * PI() / 180) * COS(d_latitude * PI() / 180) * COS((s_longitude - d_longitude) * PI() / 180)) * 180 / PI()) * 60 * 1852;

